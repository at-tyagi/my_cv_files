import cv2
import numpy as np

frame = cv2.imread('./3.jpg')
frame = cv2.resize(frame,(500,500))
def nothing(x):
    pass
    
cv2.namedWindow("color adj")
cv2.createTrackbar("lower_H","color adj",0,255,nothing)
cv2.createTrackbar("lower_S","color adj",0,255,nothing)
cv2.createTrackbar("lower_V","color adj",160,255,nothing)

cv2.createTrackbar("upper_H","color adj",65,255,nothing)
cv2.createTrackbar("upper_S","color adj",160,255,nothing)
cv2.createTrackbar("upper_V","color adj",255,255,nothing)
while True:
    hsv = cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
    l_h=cv2.getTrackbarPos("lower_H", "color adj")
    l_s=cv2.getTrackbarPos("lower_S", "color adj")
    l_v=cv2.getTrackbarPos("lower_V", "color adj")

    u_h=cv2.getTrackbarPos("upper_H", "color adj")
    u_s=cv2.getTrackbarPos("upper_S", "color adj")
    u_v=cv2.getTrackbarPos("upper_V", "color adj")
    lower_bound=np.array([l_h,l_s,l_v])
    upper_bound=np.array([u_h,u_s,u_v])

    mask=cv2.inRange(hsv,lower_bound,upper_bound)
    res=cv2.bitwise_and(frame,frame,mask=mask)
    cv2.imshow("org",frame)
    cv2.imshow('mask',mask)
    cv2.imshow('result',res)
    key=cv2.waitKey(1)
    if key==27:
        break
cv2.destroyAllWindows()