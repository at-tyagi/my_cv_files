import cv2
import numpy as np

frame1 = cv2.imread('./number_plate_recog/kk.png',0) ## use 0 to load gray image
frame = cv2.resize(frame1,(300,350))
cv2.imshow('grey',frame)
cv2.waitKey(0)
cv2.destroyAllWindows()


def nothing(x):
    pass
    
cv2.namedWindow("kernel")
cv2.createTrackbar("v1","kernel",5,31,nothing)
# cv2.createTrackbar("v2","kernel",2,100,nothing)

 
while True:
    k_size=cv2.getTrackbarPos("v1", "kernel")
    # v2=cv2.getTrackbarPos("v2", "kernel")

    try:
        lap=cv2.Laplacian(frame,cv2.CV_64F,ksize=k_size) # cv_64f handle -ve values
        sobelX=cv2.Sobel(frame,cv2.CV_64F,1,0,ksize=k_size)
        sobelY=cv2.Sobel(frame,cv2.CV_64F,0,1,ksize=k_size)
    except:
        pass
    # cv2.imshow("lap1",lap)
    lap=np.uint8(np.absolute(lap)) # take mod of -ve values convert to unsighned int
    sobelX=np.uint8(np.absolute(sobelX)) # take mod of -ve values convert to unsighned int
    sobelY=np.uint8(np.absolute(sobelY)) # take mod of -ve values convert to unsighned int
    combined_sobel = cv2.bitwise_or(sobelX,sobelY)
    cv2.imshow("laplacian",lap)
    cv2.imshow("sobelX",sobelX)
    cv2.imshow("sobelY",sobelY)
    cv2.imshow("combined sobel",combined_sobel)

    key=cv2.waitKey(1)
    if key==27:
        break
cv2.destroyAllWindows()
