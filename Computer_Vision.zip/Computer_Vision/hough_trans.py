import cv2
import numpy as np

##increase gap to fill distorted image
## it detect lines
"""
frame = cv2.imread('./screen.png') ## use 0 to load gray image
frame = cv2.resize(frame,(300,350))
img=frame.copy()
gray = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
edges=cv2.Canny(gray,138,61)
# edges=cv2.Canny(gray,20,250)

def nothing(x):
    pass
    
cv2.namedWindow("kernel")
cv2.createTrackbar("rho","kernel",1,300,nothing)
cv2.createTrackbar("angle","kernel",180,360,nothing)
cv2.createTrackbar("threshold","kernel",2,100,nothing)
cv2.createTrackbar("length","kernel",2,300,nothing)
cv2.createTrackbar("gap","kernel",2,300,nothing)

while True:

    v1=cv2.getTrackbarPos("rho", "kernel")
    v2=cv2.getTrackbarPos("angle", "kernel")
    v3=cv2.getTrackbarPos("threshold", "kernel")
    v4=cv2.getTrackbarPos("length", "kernel")
    v5=cv2.getTrackbarPos("gap", "kernel")
    try:
        lines=cv2.HoughLinesP(edges,max(1,v1),np.pi/v2,v3,
                            minLineLength=v4,maxLineGap=v5)
    except:
        pass
    ## edges, rho, angle, threshold, line length, line gap

    ## for drawing lines
    for line in lines:
        x1,y1,x2,y2 = line[0]
        cv2.line(frame,(x1,y1),(x2,y2),(0,0,255),2)

    cv2.imshow("edges",edges)
    cv2.imshow("lines",frame)
    frame = img.copy()
    key=cv2.waitKey(1)
    if key==27:
        break
cv2.destroyAllWindows()
"""



### hough circle to detect circles

frame = cv2.imread('./circles.jpeg') ## use 0 to load gray image
# frame = cv2.resize(frame,(450,500))
img = frame.copy()
gray = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
blur = cv2.medianBlur(gray,5)

def nothing(x):
    pass
    
cv2.namedWindow("kernel")
cv2.createTrackbar("rho","kernel",1,300,nothing)
cv2.createTrackbar("dist","kernel",20,360,nothing)
cv2.createTrackbar("p1","kernel",50,100,nothing)
cv2.createTrackbar("p2","kernel",30,300,nothing)
cv2.createTrackbar("r","kernel",0,300,nothing)
cv2.createTrackbar("R","kernel",0,300,nothing)

while True:

    v1=cv2.getTrackbarPos("rho", "kernel")
    v2=cv2.getTrackbarPos("dist", "kernel")
    v3=cv2.getTrackbarPos("p1", "kernel")
    v4=cv2.getTrackbarPos("p2", "kernel")
    v5=cv2.getTrackbarPos("r", "kernel")
    v6=cv2.getTrackbarPos("R", "kernel")
    try:
        circle=cv2.HoughCircles(gray,cv2.HOUGH_GRADIENT,max(1,v1),
                               v2,param1=max(v3,v4),param2=min(v3,v4),minRadius=v5,
                               maxRadius=v6)
        data=np.uint16(np.around(circle)) ## round off and unsigned
        for (x,y,r) in data[0,:]:
            cv2.circle(img,(x,y),r,(50,10,50),3)  # outer circle
            cv2.circle(img,(x,y),2,(0,255,100),-1) ## center
    except:
        pass
    cv2.imshow("gray",gray)
    cv2.imshow("circle",img)
    img = frame.copy()
    key=cv2.waitKey(1)
    if key==27:
        break
cv2.destroyAllWindows()
