import cv2
import numpy as np

frame1 = cv2.imread('../aiProff/download.png') ## use 0 to load gray image
frame = cv2.resize(frame1,(500,550))
#simple, adaptive thresholding
cv2.imshow('photo',frame)
cv2.waitKey(0)
cv2.destroyAllWindows()


def nothing(x):
    pass
    
cv2.namedWindow("color adj")
cv2.createTrackbar("val","color adj",11,255,nothing)
cv2.createTrackbar("val1","color adj",11,200,nothing)
cv2.createTrackbar("val2","color adj",2,100,nothing)



##  thresholding

# while True:
#     frame = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
#     v=cv2.getTrackbarPos("val", "color adj")
#     _, th1 = cv2.threshold(frame,v,255,cv2.THRESH_BINARY)
#     _, th2 = cv2.threshold(frame,v,255,cv2.THRESH_BINARY_INV)
#     _, th3 = cv2.threshold(frame,v,255,cv2.THRESH_TRUNC)
#     _, th4 = cv2.threshold(frame,v,255,cv2.THRESH_TOZERO)
#     cv2.imshow('result1',th1)
#     cv2.imshow('result2',th2)
#     cv2.imshow('result3',th3)
#     cv2.imshow('result4',th4)
#     key=cv2.waitKey(1)
#     if key==27:
#         break
# cv2.destroyAllWindows()




## mean

# while True:
#     frame = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
#     v=cv2.getTrackbarPos("val1", "color adj")
#     u=cv2.getTrackbarPos("val2", "color adj")
#     try:
#         th5=cv2.adaptiveThreshold(frame,255,cv2.ADAPTIVE_THRESH_MEAN_C,cv2.THRESH_BINARY,v,u)
#     except:
#         pass
#     # th5=cv2.bitwise_not(th5)
#     cv2.imshow('Adaptive',th5)
#     key=cv2.waitKey(1)
#     if key==27:
#         break
# cv2.destroyAllWindows()




###gaussian
# while True: 
#     frame = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
#     v=cv2.getTrackbarPos("val1", "color adj")
#     u=cv2.getTrackbarPos("val2", "color adj")
#     try:
#         th5=cv2.adaptiveThreshold(frame,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,v,u)
#         cv2.imshow('Adaptive',th5)
#     except:
#         pass
#     key=cv2.waitKey(1)
#     if key==27:
#         break
# cv2.destroyAllWindows()




### using thresh as mask

# frame = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
# th=cv2.adaptiveThreshold(frame,255,cv2.ADAPTIVE_THRESH_MEAN_C,cv2.THRESH_BINARY,73,11)
# th_inv=cv2.bitwise_not(th) ## to remove bg and take roi only
# img_rem=cv2.bitwise_and(frame,frame,mask=th_inv)

# cv2.imshow("mask",img_rem)
# cv2.waitKey(0)
# cv2.destroyAllWindows()
