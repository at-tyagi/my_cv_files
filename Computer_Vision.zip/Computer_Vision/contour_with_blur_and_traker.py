import cv2
import numpy as np

frame1 = cv2.imread('./3.jpg') ## use 0 to load gray image
frame = cv2.resize(frame1,(300,350))
gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)

"""
# contour -> curve fprmed by joining conteneous points
# it detects white objects with black background hense ( object should be white)
"""

def nothing(x):
    pass
cv2.namedWindow("kernel")
cv2.createTrackbar("v1","kernel",5,100,nothing)
cv2.createTrackbar("v2","kernel",2,100,nothing)
cv2.createTrackbar("blur","kernel",2,100,nothing)
cv2.createTrackbar("epsilon","kernel",100,100,nothing)

while True:

    v1=cv2.getTrackbarPos("v1", "kernel")
    v2=cv2.getTrackbarPos("v2", "kernel")
    v3=cv2.getTrackbarPos("blur", "kernel")
    v4=cv2.getTrackbarPos("epsilon", "kernel")
    try:
        thresh=cv2.adaptiveThreshold(gray,255,cv2.ADAPTIVE_THRESH_MEAN_C,cv2.THRESH_BINARY,v1,v2)
        thresh=cv2.bitwise_not(thresh)  ## now contour draw over black region
        thresh=cv2.blur(thresh,(v3,v3))   ## try without blur as well
        cv2.imshow("thresh",thresh) ## pass threshold based on what you want to detect
    except:
        pass
    cnts, hier = cv2.findContours(thresh,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

    ## list of cordinates saved to cnts

    #draw contour

    img=frame.copy()
    cnts = sorted(cnts, key=cv2.contourArea, reverse=True)


    """
    img=cv2.drawContours(img,cnts,-1,(0,0,255),2)
    ## -1 detect all contour
    ## instead of -1 pass +ve value to detect ith index contour fron lits cnts
    cv2.imshow("contours",img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    """


    ### moment contain all the information for each contour m=cv2.moments(c)

    #--------------- contour area -------
    Area = []
    for i,c in enumerate(cnts):
        M=cv2.moments(c)
        area=cv2.contourArea(c)
        Area.append(area)

        if area < 1000:
            break
        img=cv2.drawContours(img,cnts,i,(0,0,255),2)

        ## CONTOUR APPROXIMATION make same shape with minimum vertices
        epsilon = (v4/10000 )*cv2.arcLength(c,True) ## keep 0.01,0.0001 etc not more than 0.01 it changes dimension of bounding rectangle
        data = cv2.approxPolyDP(c,epsilon,True) ## true return value to data

        ## convex Hull  = total area bound provide convexity
        hull=cv2.convexHull(data) ## draw a hull

        x,y,w,h = cv2.boundingRect(hull)
        img=cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2)

    # convexHull is rectangle here
    cv2.imshow("rect",img)
    key=cv2.waitKey(1)
    if key==27:
        break
cv2.destroyAllWindows()




