import cv2
import numpy as np

frame = cv2.imread('./number_plate_recog/w5.png',0) ## use 0 to load gray image
frame = cv2.resize(frame,(500,500))
# cv2.imshow('grey',frame)
# cv2.waitKey(0)
# cv2.destroyAllWindows()


def nothing(x):
    pass
    
cv2.namedWindow("kernel")
cv2.createTrackbar("v1","kernel",169,1000,nothing)
cv2.createTrackbar("v2","kernel",233,1000,nothing)


while True:
    v1=cv2.getTrackbarPos("v1", "kernel")
    v2=cv2.getTrackbarPos("v2", "kernel")

    # try:
    canny=cv2.Canny(frame,v1,v2)
    # except:
        # pass
    cv2.imshow("canny",canny)
    cnts, hier = cv2.findContours(canny,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

    ## list of cordinates saved to cnts

    #draw contour

    img=frame.copy()
    cnts = sorted(cnts, key=cv2.contourArea, reverse=True)

    img=cv2.drawContours(img,cnts,-1,(0,0,255),1)
    ## -1 detect all contour
    ## instead of -1 pass +ve value to detect ith index contour fron lits cnts
    cv2.imshow("contours",img)
    key=cv2.waitKey(1)
    if key==27:
        break
cv2.destroyAllWindows()