import cv2
import numpy as np

frame1 = cv2.imread('./screen.png',0) ## use 0 to load gray image
frame = cv2.resize(frame1,(300,350))
# cv2.imshow('grey',frame)
# cv2.waitKey(0)
# cv2.destroyAllWindows()



pd1=cv2.pyrDown(frame) #improve pixels
pu1=cv2.pyrUp(frame) # is destroy pixels
    
cv2.imshow("down pyramid",pd1)
cv2.imshow("up pyramid",pu1)
cv2.waitKey(0)
cv2.destroyAllWindows()
