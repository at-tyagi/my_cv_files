import cv2
import numpy as np

frame1 = cv2.imread('./group.jpg') ## use 0 to load gray image
f=frame1
gray=cv2.cvtColor(frame1,cv2.COLOR_BGR2GRAY)
template=cv2.imread("template.jpg",0)
w,h=template.shape[::-1]
res=cv2.matchTemplate(gray,template,cv2.TM_CCORR_NORMED)

def nothing(x):
    pass
    
cv2.namedWindow("kernel")
cv2.createTrackbar("v1","kernel",90,100,nothing) ## more than 90 always

while True:
    v1=max(89,cv2.getTrackbarPos("v1", "kernel"))
    loc=np.where(res>=v1/100)
    for i in zip(*loc[::-1]):
        cv2.rectangle(frame1,i,(i[0]+w,i[1]+h),(0,0,255),2)
        #i contain cordinates
    frame = cv2.resize(frame1,(300,350))
    cv2.imshow('Actal',frame)
    cv2.imshow('res',cv2.resize(res,(300,350)))
    key=cv2.waitKey(1)
    if key==27:
        break
    frame1=cv2.imread('./group.jpg')
    res=cv2.matchTemplate(gray,template,cv2.TM_CCORR_NORMED) ## try multiple methods

cv2.destroyAllWindows()


## dont resize image before matching and making recttangle 
## crop template from image
