import cv2
import numpy as np

frame = cv2.imread('./number_plate_recog/6.jpg')
frame = cv2.resize(frame,(500,500))
def nothing(x):
    pass
    
cv2.namedWindow("color adj")
cv2.createTrackbar("alpha","color adj",0,255,nothing)
cv2.createTrackbar("beta","color adj",0,255,nothing)

while True:
    u=cv2.getTrackbarPos("alpha", "color adj")
    v=cv2.getTrackbarPos("beta", "color adj")
    i=cv2.convertScaleAbs(frame, alpha=u, beta=v)
    cv2.imshow("org",frame)
    cv2.imshow('result',i)
    key=cv2.waitKey(1)
    if key==27:
        break
cv2.destroyAllWindows()