import cv2
import numpy as np

frame1 = cv2.imread('./screen.png',0) ## use 0 to load gray image
frame = cv2.resize(frame1,(300,350))
# cv2.imshow('grey',frame)
# cv2.waitKey(0)
# cv2.destroyAllWindows()

def nothing(x):
    pass
    
cv2.namedWindow("kernel")
cv2.createTrackbar("v1","kernel",2,20,nothing)
cv2.createTrackbar("v2","kernel",2,20,nothing)


mask=cv2.adaptiveThreshold(frame,255,cv2.ADAPTIVE_THRESH_MEAN_C,cv2.THRESH_BINARY,73,11)
while True:
    v1=cv2.getTrackbarPos("v1", "kernel")
    v2=cv2.getTrackbarPos("v2", "kernel")
    # cv2.imshow('threshold',mask)

    kernel=np.ones((v1,v1),np.uint8) ## black pixel hover on image
    e=cv2.erode(mask,kernel) ## make boundary sharper work outside object

    kernel_d=np.ones((v2,v2),np.uint8)
    d=cv2.dilate(e,kernel_d) ## work inside object oppo. of erosion/ work on mask directly as well

    o=cv2.morphologyEx(mask,cv2.MORPH_OPEN,kernel) ## combination of erosion then dilation
    c=cv2.morphologyEx(mask,cv2.MORPH_CLOSE,kernel) ## combination of erosion after dilation

    # cv2.imshow("erosion",e)
    cv2.imshow("dilation & erosion",d)
    cv2.imshow("opening",o)
    cv2.imshow("closing",c)
    key=cv2.waitKey(1)
    if key==27:
        break
cv2.destroyAllWindows()