import numpy as np 
import cv2

cap=cv2.VideoCapture(0)

def nothing(x):
    pass

cv2.namedWindow("color adj", cv2.WINDOW_NORMAL)
cv2.resizeWindow("color adj",(300,300))
cv2.createTrackbar("Thresh","color adj",0,255,nothing)


cv2.createTrackbar("lower_H","color adj",0,255,nothing)
cv2.createTrackbar("lower_S","color adj",33,255,nothing)
cv2.createTrackbar("lower_V","color adj",20,255,nothing)

cv2.createTrackbar("upper_H","color adj",255,255,nothing)
cv2.createTrackbar("upper_S","color adj",255,255,nothing)
cv2.createTrackbar("upper_V","color adj",255,255,nothing)

while True:
    _,frame=cap.read()
    if not _:
        print("Error in camera")
        break
    frame=cv2.resize(frame,(400,400))
    hsv = cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
    l_h=cv2.getTrackbarPos("lower_H", "color adj")
    l_s=cv2.getTrackbarPos("lower_S", "color adj")
    l_v=cv2.getTrackbarPos("lower_V", "color adj")

    u_h=cv2.getTrackbarPos("upper_H", "color adj")
    u_s=cv2.getTrackbarPos("upper_S", "color adj")
    u_v=cv2.getTrackbarPos("upper_V", "color adj")
    lower_bound=np.array([l_h,l_s,l_v])
    upper_bound=np.array([u_h,u_s,u_v])

    mask=cv2.inRange(hsv,lower_bound,upper_bound)

    # mask=cv2.bitwise_not(mask)
    m_g = cv2.getTrackbarPos("Thresh","color adj")
    ret,thresh = cv2.threshold(mask,m_g,255,cv2.THRESH_BINARY)
    dilate=cv2.dilate(thresh,(1,1),iterations=6)

    cnts,hier=cv2.findContours(thresh,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    frame=cv2.drawContours(frame,cnts,-1,(0,0,255),4)

    cv2.imshow('thresh',thresh)
    cv2.imshow('result',dilate)
    cv2.imshow('contour',frame)
    key=cv2.waitKey(1)
    if key==27:
        break
cv2.destroyAllWindows()