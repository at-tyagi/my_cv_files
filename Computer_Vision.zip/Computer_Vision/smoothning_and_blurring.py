import cv2
import numpy as np

frame1 = cv2.imread('/home/at_tyagi/Desktop/wattapad/images/Images/cat/15.png') ## use 0 to load gray image
frame = cv2.resize(frame1,(300,350))
cv2.imshow('grey',frame)
cv2.waitKey(0)
cv2.destroyAllWindows()


def nothing(x):
    pass
    
cv2.namedWindow("kernel")
cv2.createTrackbar("v1","kernel",5,100,nothing)
cv2.createTrackbar("v2","kernel",2,100,nothing)


while True:
    v1=cv2.getTrackbarPos("v1", "kernel")
    v2=cv2.getTrackbarPos("v2", "kernel")

    kernel=np.ones((v1,v1),np.float32)/(v1*v1) ## pixel hover on image divide by matrix area
    try:
        h_filter=cv2.filter2D(frame,-1,kernel) ## take mean of neighbour element
        blur=cv2.blur(frame,(v1,v1))  # replace by central element
        gau=cv2.GaussianBlur(frame,(v1,v1),v2) # gaussian blur use matrix v1xv1 with smallvalues at boundary and large value at center
        med=cv2.medianBlur(frame,v1)  ## highly effective on salt and pepper noise ( v1 always odd )
        bi_f=cv2.bilateralFilter(frame,v2,v1,v1) ## work more on edges keep them sharp same as gaussian filter check documentation
    except:
        pass
    cv2.imshow("h filter",h_filter)
    cv2.imshow("blur",blur)
    cv2.imshow("gaussian blur",gau)
    cv2.imshow("median blur",med)
    cv2.imshow("bilateral blur",bi_f)

    key=cv2.waitKey(1)
    if key==27:
        break
cv2.destroyAllWindows()
