import cv2
import numpy as np

frame1 = cv2.imread('./3.jpg') ## use 0 to load gray image
frame = cv2.resize(frame1,(300,350))
gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)


# contour -> curve fprmed by joining conteneous points
# it detects white objects with black background hense ( object should be white)


thresh=cv2.adaptiveThreshold(gray,255,cv2.ADAPTIVE_THRESH_MEAN_C,cv2.THRESH_BINARY,23,11)
thresh=cv2.bitwise_not(thresh)
cv2.imshow("thresh",thresh) ## pass threshold based on what you want to detect
cv2.waitKey(0)
cv2.destroyAllWindows()


cnts, hier = cv2.findContours(thresh,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

## list of cordinates saved to cnts
print(len(cnts))

#draw contour

img=frame.copy()
cnts = sorted(cnts, key=cv2.contourArea, reverse=True)


"""
img=cv2.drawContours(img,cnts,-1,(0,0,255),2)
## -1 detect all contour
## instead of -1 pass +ve value to detect ith index contour fron lits cnts
cv2.imshow("contours",img)
cv2.waitKey(0)
cv2.destroyAllWindows()
"""


### moment contain all the information for each contour m=cv2.moments(c)

#--------------- contour area -------
Area = []
for i,c in enumerate(cnts):
    M=cv2.moments(c)
    area=cv2.contourArea(c)
    Area.append(area)

    if area < 500:
        break
    img=cv2.drawContours(img,cnts,i,(0,0,255),2)

    ## CONTOUR APPROXIMATION make same shape with minimum vertices
    epsilon = 0.001*cv2.arcLength(c,True) ## keep 0.1,0.001 etc not more than 0.1 it changes dimension of bounding rectangle
    data = cv2.approxPolyDP(c,epsilon,True) ## true return value to data

    ## convex Hull  = total area bound provide convexity
    hull=cv2.convexHull(data) ## draw a hull

    x,y,w,h = cv2.boundingRect(hull)
    img=cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2)

# convexHull is rectangle here
cv2.imshow("rect",img)
cv2.waitKey(0)
cv2.destroyAllWindows()




